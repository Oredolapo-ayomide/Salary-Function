# Load base utils 
library(utils)
# Step 1: Define zip file path and output folder
zip_file <- "Employee_Profile.zip"
output_dir <- "Employee Profile"

# Step 2: Unzip the file
if (!dir.exists(output_dir)) {
  dir.create(output_dir)
}
unzip(zip_file, exdir = output_dir)
cat("Folder unzipped successfully to:", output_dir, "\n")

# Step 3: List and read CSV files
csv_files <- list.files(output_dir, pattern = "\\.csv$", full.names = TRUE)

if (length(csv_files) == 0) {
  cat(" No CSV files found inside the unzipped folder.\n")
} else {
  for (file in csv_files) {
    cat("\n Reading file:", file, "\n")
    data <- read.csv(file, stringsAsFactors = FALSE)
    print(data)
  }
}